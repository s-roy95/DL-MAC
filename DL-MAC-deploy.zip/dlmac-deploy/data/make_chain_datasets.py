#!/usr/bin/env python3
"""
Build chain-dataset CSVs for the two shipped workflows (staircase_chain,
random_chain) in the SAME schema as chains_test.csv:

  chain_id, arrival_time, edge_server_id, func_type, chain_deadline,
  profit, func_delay, mb, cores

Each chain is expanded to one row per stage. Per-stage fields (func_type,
func_delay, mb, cores) come from the workflow DAG's `transform` stages
(rounds -> delay/mb/cores); per-chain fields (arrival_time, edge_server_id,
chain_deadline, profit) are drawn from the same distributions used for the
Azure-derived chains_test.csv.
"""
import os, json, csv, random

HERE = os.path.dirname(os.path.abspath(__file__))
WF_DIR = os.path.join(HERE, "..", "workflows_real")
N_CHAINS = 250                # chains per workflow
ARRIVAL_SPAN = 600.0         # seconds
N_EDGE = 30                  # edge servers (matches graph.txt)
DEADLINE_MULT = 1.6         # chain_deadline = round(mult * sum(func_delay))
random.seed(42)

def stage_metrics(rounds):
    """Map a transform stage's `rounds` to (func_type, func_delay, mb, cores)."""
    func_type = f"transform_r{rounds}"
    func_delay = rounds                          # delay units, like chains_test integer delays
    mb = round(rounds * 96 + random.uniform(-8, 8), 1)   # payload MB, rounds-scaled
    cores = round(0.08 + 0.06 * rounds + random.uniform(-0.02, 0.02), 3)
    return func_type, func_delay, mb, cores

def build(wf_name, out_csv):
    spec = json.load(open(os.path.join(WF_DIR, wf_name + ".json")))
    stages = spec["stages"]; nS = len(stages)
    rows = []
    for j in range(N_CHAINS):
        arrival = round(random.uniform(0, ARRIVAL_SPAN), 3)
        home = random.randint(1, N_EDGE)
        per = [stage_metrics(int(st["args"].get("rounds", 3))) for st in stages]
        sum_delay = sum(p[1] for p in per)
        deadline = int(round(DEADLINE_MULT * sum_delay))
        profit = round(random.uniform(0.9, 1.3) * nS * 1.5, 2)   # ~55-80 for 40+ stages
        cid = f"{wf_name.split('_')[0]}_{j}"
        for (ft, fd, mb, cores) in per:
            rows.append([cid, arrival, home, ft, deadline, profit, fd, mb, cores])
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["chain_id","arrival_time","edge_server_id","func_type",
                    "chain_deadline","profit","func_delay","mb","cores"])
        w.writerows(rows)
    print(f"{wf_name}: {N_CHAINS} chains x {nS} stages -> {len(rows)} rows  ({out_csv})")

if __name__ == "__main__":
    build("staircase_chain", os.path.join(HERE, "staircase_chain.csv"))
    build("random_chain",    os.path.join(HERE, "random_chain.csv"))
