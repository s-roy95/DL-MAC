#!/usr/bin/env python3
"""
Task-runner container for the DL-MAC edge-cloud FaaS deployment.

One HTTP server = one warm "function instance" on an edge server. The scheduler
POSTs a stage to /run; the server executes REAL CPU work (a compression
transform used by the deep function chains) and returns measured timings.
Reusing a running server = warm start; a freshly created one pays the
pod/container cold start (measured by the scheduler as create -> /ready).

Only the `transform` stage is needed for the two shipped workflows
(staircase_chain, random_chain); the image is therefore a plain
python:3.11-slim with no external media libraries.
"""
import os, json, time, zlib, http.server, socketserver

DATA = os.environ.get("DATA_DIR", "/data")
FUNC = os.environ.get("FUNC_TYPE", "generic")   # function type this instance is warm for
os.makedirs(DATA, exist_ok=True)

# ---------------------------------------------------------------- real stage
def transform(args):
    """Compression rounds for deep chains (real CPU work + real bytes)."""
    rounds = int(args.get("rounds", 3))
    blob = os.urandom(int(args.get("kb", 512)) * 1024)
    for _ in range(rounds):
        blob = zlib.compress(blob) + os.urandom(4096)
    return {"out_bytes": len(blob), "rounds": rounds}

STAGES = {"transform": transform}

# ---------------------------------------------------------------- HTTP server
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/ready": self._send(200, {"ready": True, "func": FUNC})
        else: self._send(404, {"error": "not found"})
    def do_POST(self):
        if self.path != "/run": return self._send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0)); req = json.loads(self.rfile.read(n) or b"{}")
        stage = req.get("stage"); args = req.get("args", {})
        if stage not in STAGES: return self._send(400, {"error": f"unknown stage {stage}"})
        t0 = time.time()
        try:
            res = STAGES[stage](args); ok = True
        except Exception as e:
            res = {"error": str(e)}; ok = False
        self._send(200 if ok else 500, {"stage": stage, "ok": ok, "compute_s": round(time.time()-t0, 4), "result": res})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    with socketserver.ThreadingTCPServer(("", port), H) as srv:
        print(f"task-runner ready on :{port} (warm for {FUNC})", flush=True)
        srv.serve_forever()
