"""
Edge-server pool with warm/cold instance management and measured cold starts.

Each edge server hosts warm function instances (one task-runner per function
type). Reusing a running instance = warm start; creating one pays a measured
cold start (spawn -> /ready). Two backends:

  * local  : task-runners are local subprocesses on distinct ports (no Docker;
             good for a laptop / CI). Cold start = process start -> /ready.
  * http   : task-runners are Docker-compose / k8s pods reachable by URL; the
             same server.py image is used (see task-runner/Dockerfile). Cold
             start = pod create -> /ready (handled by the compose/k8s layer).

This mirrors the DCD k8s_pool (create/reuse/revoke + cold-start timing); here a
"pod" is an edge-server-local warm instance keyed by (server, function type).
"""
import os, sys, time, json, socket, subprocess, urllib.request

SERVER = os.path.join(os.path.dirname(__file__), "..", "task-runner", "server.py")

def _free_port():
    s = socket.socket(); s.bind(("", 0)); p = s.getsockname()[1]; s.close(); return p

def _post(url, payload, timeout=120):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())

def _ready(url, deadline_s):
    t0 = time.time()
    while time.time() - t0 < deadline_s:
        try:
            with urllib.request.urlopen(url + "/ready", timeout=2) as r:
                if json.loads(r.read()).get("ready"): return True
        except Exception:
            time.sleep(0.05)
    return False

class EdgePool:
    def __init__(self, data_dir, backend="local", cold_penalty=2.0, keep_alive=30.0):
        self.data_dir = os.path.abspath(data_dir); os.makedirs(self.data_dir, exist_ok=True)
        self.backend = backend; self.cold_penalty = cold_penalty; self.keep_alive = keep_alive
        self.warm = {}   # (server_id, func_type) -> {"proc","url","last"}
        self.cold_starts = 0; self.warm_hits = 0

    # ---- instance lifecycle ----
    def _spawn_local(self, func_type):
        port = _free_port(); env = dict(os.environ, PORT=str(port), DATA_DIR=self.data_dir, FUNC_TYPE=func_type)
        proc = subprocess.Popen([sys.executable, os.path.abspath(SERVER)], env=env,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        url = f"http://127.0.0.1:{port}"
        return proc, url

    def instance(self, server_id, func_type):
        """Return (url, cold_start_seconds). Warm reuse if the type is resident."""
        key = (server_id, func_type)
        if key in self.warm:
            self.warm_hits += 1; self.warm[key]["last"] = time.time()
            return self.warm[key]["url"], 0.0
        # cold start
        t0 = time.time()
        if self.backend == "local":
            proc, url = self._spawn_local(func_type)
            if not _ready(url, deadline_s=30):
                proc.terminate(); raise RuntimeError("instance failed to become ready")
        else:
            raise NotImplementedError("http/k8s backend: point instance() at your pod URLs")
        cold = time.time() - t0 + self.cold_penalty
        self.warm[key] = {"proc": proc, "url": url, "last": time.time()}
        self.cold_starts += 1
        return url, cold

    def run(self, server_id, func_type, stage, args):
        """Execute one stage on an edge server; returns dict with cold_s + compute_s."""
        url, cold = self.instance(server_id, func_type)
        resp = _post(url + "/run", {"stage": stage, "args": args})
        return {"cold_s": round(cold, 4), "compute_s": resp.get("compute_s", 0.0),
                "ok": resp.get("ok", False), "result": resp.get("result", {})}

    def evict_idle(self):
        now = time.time()
        for key in [k for k, v in self.warm.items() if now - v["last"] > self.keep_alive]:
            self._kill(key)

    def _kill(self, key):
        v = self.warm.pop(key, None)
        if v and v.get("proc"):
            try: v["proc"].terminate()
            except Exception: pass

    def shutdown(self):
        for key in list(self.warm): self._kill(key)
