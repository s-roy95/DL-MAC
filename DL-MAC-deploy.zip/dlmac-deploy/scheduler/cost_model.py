"""
Profit / deadline / welfare accounting for the DL-MAC edge-cloud deployment.

Total profit follows the paper: a chain earns its full revenue P_j only if every
stage meets its deadline (All-or-Nothing); welfare is Jain's fairness index over
per-server load. Transport cost mirrors the distance model (edge-edge vs
edge-cloud hops).
"""

class Cfg:
    d_h = 2.0        # per-hop edge-edge delay (s)
    d_ec = 5.0       # edge-cloud link delay (s)
    d_cp = 3.0       # cloud wait (s)
    pub_fetch = 1.0  # warm fetch from a neighbour's public pool (s)
    cold = 2.0       # cold-start penalty (s)
    alpha_n = 0.80   # profit fraction to neighbour executor
    alpha_c = 0.80   # profit fraction to cloud executor

def transport(home, node, dist, cfg=Cfg):
    """Communication delay of running a stage on `node` for a chain homed at `home`."""
    if node == home: return 0.0
    if node == "CC": return dist[home]["gw"] * cfg.d_h + cfg.d_ec + cfg.d_cp
    return dist[home][node] * cfg.d_h

def jain(loads):
    xs = [max(0.0, x) for x in loads]; s = sum(xs)
    return (s * s) / (len(xs) * sum(x * x for x in xs) + 1e-12) if s > 1e-9 else 1.0
