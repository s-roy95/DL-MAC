"""
Placement policies (which edge node runs a stage), matching the paper's methods.

Each policy is a function pick(ctx) -> target node id (an edge-server id, the
home server id, or "CC" for cloud), given a context describing the home server,
its K-hop neighbours, per-node congestion, and which nodes hold the function
warm (private/public pools).

  S-Cache    : run everything on the home server (no cooperation).
  CoCache    : K-hop neighbour reuse; prefer a neighbour holding it warm.
  DSP        : demand-aware private/public placement (highest-demand feasible node).
  pCache     : probabilistic placement (avoid hotspots) with prob p.
  DL-LRU     : greedy dual-Lagrangian rule  argmin  Q_i*w - V*profit.
  DL-MAC     : learned actor (loads a policy if provided; else falls back to DL-LRU).
  Offline-Opt: least-congested feasible node (oracle-style, deployment proxy).
"""
import random

def _feasible(ctx):
    return ctx["candidates"]  # already filtered to deadline-feasible {home}∪neighbours∪{CC}

def s_cache(ctx):
    return ctx["home"]

def cocache(ctx):
    warm = [n for n in ctx["candidates"] if n != "CC" and ctx["warm"].get(n)]
    if ctx["warm"].get(ctx["home"]): return ctx["home"]
    return warm[0] if warm else (ctx["home"] if ctx["home"] in ctx["candidates"] else "CC")

def dsp(ctx):
    edge = [n for n in ctx["candidates"] if n != "CC"]
    if not edge: return "CC"
    return max(edge, key=lambda n: ctx["demand"].get(n, 0))   # highest observed demand

def pcache(ctx, p=0.40):
    edge = [n for n in ctx["candidates"] if n != "CC"]
    if not edge: return "CC"
    if random.random() < p: return ctx["home"] if ctx["home"] in edge else edge[0]
    return random.choice(edge)                                # spread to avoid hotspots

def dl_lru(ctx, V=1.0):
    edge = [n for n in ctx["candidates"] if n != "CC"]
    if not edge: return "CC"
    # dual-Lagrangian metric: congestion price Q_i * workload  -  V * profit share
    def metric(n):
        w = ctx["stage_work"]; prof = ctx["profit"]
        return ctx["price"].get(n, 0.0) * w - V * prof
    return min(edge, key=metric)

def dl_mac(ctx):
    model = ctx.get("model")
    if model is None:                      # no trained actor available at deploy time
        return dl_lru(ctx)
    return model.act(ctx)                  # learned per-edge actor (see README)

def offline_opt(ctx):
    edge = [n for n in ctx["candidates"] if n != "CC"]
    if not edge: return "CC"
    return min(edge, key=lambda n: ctx["load"].get(n, 0.0))   # least-loaded feasible node

POLICIES = {
    "s_cache": s_cache, "cocache": cocache, "dsp": dsp, "pcache": pcache,
    "dl_lru": dl_lru, "dl_mac": dl_mac, "offline_opt": offline_opt,
}
